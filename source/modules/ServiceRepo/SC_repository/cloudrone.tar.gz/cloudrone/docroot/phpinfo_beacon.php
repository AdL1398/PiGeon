 <?php
//$myfile = fopen("beacon.txt", "r") or die("Unable to open file!");
 //fread($myfile,filesize("beacon.txt"));
 $sensor1= file_get_contents('uploads/sensor1.txt');
 $sensor2= file_get_contents('uploads/sensor2.txt');
 $sensor3= file_get_contents('uploads/sensor3.txt');
 $rows = array(); 

 array_push($rows, $sensor1, $sensor2, $sensor3);
 echo json_encode($rows); 
 







?>
