<?php
  mysql_connect("db", "root", "password")or die("cannot connect to server");
          mysql_select_db('testdb')or die("cannot select Database");

 $sql = "SELECT lat,lng,thumbnail,url,video,caption FROM upload_img order by img_id ";

$rs = mysql_query($sql);
if (!$rs) {
    echo "An SQL error occured.\n";
    exit;
}
$return_arr = array();
//$rows = array();
while($r = mysql_fetch_array($rs) ){

    //$rows[] = $r;
        $row_array['lat'] = $r['lat'];
    $row_array['lng'] = $r['lng'];
    $row_array['thumbnail'] = $r['thumbnail'];
        $row_array['url'] = $r['url'];
    $row_array['video'] = $r['video'];
         $row_array['caption'] = $r['caption'];

    array_push($return_arr,$row_array);


}  //while


$fp = fopen('rows.json', 'w');
  // fwrite($fp, json_encode($rows));
  fwrite($fp, json_encode(array('rows' => $return_arr)));

  fclose($fp);

?>
