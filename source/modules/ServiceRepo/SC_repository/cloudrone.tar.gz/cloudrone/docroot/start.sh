#!/bin/bash
python  testblescan.py

