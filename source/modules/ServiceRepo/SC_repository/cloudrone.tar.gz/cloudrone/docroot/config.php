<?php
 $final_width_of_image = 100;
$path_to_image_directory = "uploads/fullsized/";
$path_to_thumbs_directory = "uploads/thumbs/";
?>