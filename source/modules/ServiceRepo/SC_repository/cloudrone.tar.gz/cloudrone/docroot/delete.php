<?php 
$file = fopen("testblescan.py","r") or die("unable to open");





?>
