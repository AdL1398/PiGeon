#!/bin/bash
cd /scanner
python  /scanner/testblescan.py

