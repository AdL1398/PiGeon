#!/bin/bash
cd /sync
while true
do
        rsync -a /sync/  pi@192.168.1.4:/home/pk/cloudrone/docroot/uploads


done



